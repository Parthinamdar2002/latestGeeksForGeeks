import React from "react";
import Tilt from "react-tilt";
import { motion } from "framer-motion";

import { styles } from "../styles";
import { services } from "../constants";
import { SectionWrapper } from "../hoc";
import { fadeIn, textVariant } from "../utils/motion";

const ServiceCard = ({ index, title, icon }) => (
  <Tilt className='xs:w-[250px] w-full'>
    <motion.div
      variants={fadeIn("right", "spring", index * 0.5, 0.75)}
      className='w-full green-pink-gradient p-[1px] rounded-[20px] shadow-card'
    >
      <div
        options={{
          max: 45,
          scale: 1,
          speed: 450,
        }}
        className='bg-tertiary rounded-[20px] py-5 px-12 min-h-[280px] flex justify-evenly items-center flex-col'
      >
        <img
          src={icon}
          alt='web-development'
          className='w-16 h-16 object-contain'
        />

        <h3 className='text-white text-[20px] font-bold text-center'>
          {title}
        </h3>
      </div>
    </motion.div>
  </Tilt>
);

const About = () => {
  return (
    <>
      <motion.div variants={textVariant()}>
        {/* <p className={styles.sectionSubText}>Introduction</p> */}
        {/* <h2 className={styles.sectionHeadText}>About Us</h2> */}
      </motion.div>

      <motion.p
        variants={fadeIn("", "", 0.1, 1)}
        className='mt-10 text-secondary text-[17px] max-w-7xl leading-[30px]'
      >
        The Syayambhu National Level Technical Event held by MGM University Aurangabad was an extraordinary showcase of talent, innovation, and technical expertise. It brought together participants from all over the country to compete, collaborate, and exchange ideas in a dynamic environment. The event featured a wide range of technical competitions, workshops, and exhibitions that encompassed various domains including robotics, coding, app development, and circuit designing.
        <br /><br />
        Participants had the opportunity to demonstrate their skills and knowledge through project presentations and competitions, pushing the boundaries of innovation and creativity. Industry experts and academicians conducted insightful workshops and seminars, providing valuable insights into emerging technologies and industry trends.
        <br /><br />
        Moreover, Syayambhu served as a platform for participants to network and forge connections with professionals and peers, fostering collaboration and knowledge sharing. The event celebrated the spirit of technical excellence and served as a catalyst for the growth and development of participants in the ever-evolving field of technology.
        <br /><br />
        Overall, the Syayambhu National Level Technical Event at MGM University Aurangabad created a conducive environment for learning, exploration, and inspiration, making it a significant milestone in the technical calendar.
      </motion.p>

      {/* <div className='mt-20 flex flex-wrap gap-10'>
        {services.map((service, index) => (
          <ServiceCard key={service.title} index={index} {...service} />
        ))}
      </div> */}
    </>
  );
};

export default SectionWrapper(About, "");
